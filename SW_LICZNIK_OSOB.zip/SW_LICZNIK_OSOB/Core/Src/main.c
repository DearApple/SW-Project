/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2022 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "cmsis_os.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
osThreadId defaultTaskHandle;
osThreadId myTask1Handle;
osThreadId myTask2Handle;
osThreadId myTask03Handle;
osMessageQId ilosc_osob_QueueHandle;
osTimerId Timer_DEBOUNCERHandle;
osTimerId Timer2Handle;
osTimerId TimREPHandle;
osSemaphoreId DebouncingSemaphoreHandle;
osSemaphoreId TrybSemaphoreHandle;
osSemaphoreId ResetSemaphoreHandle;
osSemaphoreId ZwiekszanieSemaphoreHandle;
osSemaphoreId Czujnik1SemaphoreHandle;
osSemaphoreId Czujnik2SemaphoreHandle;
osSemaphoreId MiganieSemaphoreHandle;
osSemaphoreId Reset2SemaphoreHandle;
osSemaphoreId RepSemaphoreHandle;
/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
void StartDefaultTask(void const * argument);
void Task1(void const * argument);
void Task2(void const * argument);
void Task3(void const * argument);
void Callback1(void const * argument);
void Callback02(void const * argument);
void Callback03(void const * argument);

/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  /* USER CODE BEGIN 2 */

  /* USER CODE END 2 */

  /* USER CODE BEGIN RTOS_MUTEX */
  /* add mutexes, ... */
  /* USER CODE END RTOS_MUTEX */

  /* Create the semaphores(s) */
  /* definition and creation of DebouncingSemaphore */
  osSemaphoreDef(DebouncingSemaphore);
  DebouncingSemaphoreHandle = osSemaphoreCreate(osSemaphore(DebouncingSemaphore), 1);

  /* definition and creation of TrybSemaphore */
  osSemaphoreDef(TrybSemaphore);
  TrybSemaphoreHandle = osSemaphoreCreate(osSemaphore(TrybSemaphore), 1);

  /* definition and creation of ResetSemaphore */
  osSemaphoreDef(ResetSemaphore);
  ResetSemaphoreHandle = osSemaphoreCreate(osSemaphore(ResetSemaphore), 1);

  /* definition and creation of ZwiekszanieSemaphore */
  osSemaphoreDef(ZwiekszanieSemaphore);
  ZwiekszanieSemaphoreHandle = osSemaphoreCreate(osSemaphore(ZwiekszanieSemaphore), 1);

  /* definition and creation of Czujnik1Semaphore */
  osSemaphoreDef(Czujnik1Semaphore);
  Czujnik1SemaphoreHandle = osSemaphoreCreate(osSemaphore(Czujnik1Semaphore), 1);

  /* definition and creation of Czujnik2Semaphore */
  osSemaphoreDef(Czujnik2Semaphore);
  Czujnik2SemaphoreHandle = osSemaphoreCreate(osSemaphore(Czujnik2Semaphore), 1);

  /* definition and creation of MiganieSemaphore */
  osSemaphoreDef(MiganieSemaphore);
  MiganieSemaphoreHandle = osSemaphoreCreate(osSemaphore(MiganieSemaphore), 1);

  /* definition and creation of Reset2Semaphore */
  osSemaphoreDef(Reset2Semaphore);
  Reset2SemaphoreHandle = osSemaphoreCreate(osSemaphore(Reset2Semaphore), 1);

  /* definition and creation of RepSemaphore */
  osSemaphoreDef(RepSemaphore);
  RepSemaphoreHandle = osSemaphoreCreate(osSemaphore(RepSemaphore), 1);

  /* USER CODE BEGIN RTOS_SEMAPHORES */
  /* add semaphores, ... */
  /* USER CODE END RTOS_SEMAPHORES */

  /* Create the timer(s) */
  /* definition and creation of Timer_DEBOUNCER */
  osTimerDef(Timer_DEBOUNCER, Callback1);
  Timer_DEBOUNCERHandle = osTimerCreate(osTimer(Timer_DEBOUNCER), osTimerPeriodic, NULL);

  /* definition and creation of Timer2 */
  osTimerDef(Timer2, Callback02);
  Timer2Handle = osTimerCreate(osTimer(Timer2), osTimerPeriodic, NULL);

  /* definition and creation of TimREP */
  osTimerDef(TimREP, Callback03);
  TimREPHandle = osTimerCreate(osTimer(TimREP), osTimerPeriodic, NULL);

  /* USER CODE BEGIN RTOS_TIMERS */
  /* start timers, add new ones, ... */
  /* USER CODE END RTOS_TIMERS */

  /* Create the queue(s) */
  /* definition and creation of ilosc_osob_Queue */
  osMessageQDef(ilosc_osob_Queue, 5, uint8_t);
  ilosc_osob_QueueHandle = osMessageCreate(osMessageQ(ilosc_osob_Queue), NULL);

  /* USER CODE BEGIN RTOS_QUEUES */
  /* add queues, ... */
  /* USER CODE END RTOS_QUEUES */

  /* Create the thread(s) */
  /* definition and creation of defaultTask */
  osThreadDef(defaultTask, StartDefaultTask, osPriorityIdle, 0, 128);
  defaultTaskHandle = osThreadCreate(osThread(defaultTask), NULL);

  /* definition and creation of myTask1 */
  osThreadDef(myTask1, Task1, osPriorityNormal, 0, 128);
  myTask1Handle = osThreadCreate(osThread(myTask1), NULL);

  /* definition and creation of myTask2 */
  osThreadDef(myTask2, Task2, osPriorityNormal, 0, 128);
  myTask2Handle = osThreadCreate(osThread(myTask2), NULL);

  /* definition and creation of myTask03 */
  osThreadDef(myTask03, Task3, osPriorityNormal, 0, 128);
  myTask03Handle = osThreadCreate(osThread(myTask03), NULL);

  /* USER CODE BEGIN RTOS_THREADS */
  /* add threads, ... */
  /* USER CODE END RTOS_THREADS */

  /* Start scheduler */
  osKernelStart();

  /* We should never get here as control is now taken by the scheduler */
  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);
  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 8;
  RCC_OscInitStruct.PLL.PLLN = 100;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_3) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();
  __HAL_RCC_GPIOE_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();
  __HAL_RCC_GPIOC_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, Anoda1_Pin|Anoda2_Pin|SegA_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOE, SegB_Pin|SegC_Pin|SegD_Pin|SegE_Pin
                          |SegF_Pin|SegG_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(LED_GPIO_Port, LED_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pins : Tryb_Pin Zwiekszanie_Pin */
  GPIO_InitStruct.Pin = Tryb_Pin|Zwiekszanie_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : Anoda1_Pin Anoda2_Pin SegA_Pin */
  GPIO_InitStruct.Pin = Anoda1_Pin|Anoda2_Pin|SegA_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pins : SegB_Pin SegC_Pin SegD_Pin SegE_Pin
                           SegF_Pin SegG_Pin */
  GPIO_InitStruct.Pin = SegB_Pin|SegC_Pin|SegD_Pin|SegE_Pin
                          |SegF_Pin|SegG_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOE, &GPIO_InitStruct);

  /*Configure GPIO pin : LED_Pin */
  GPIO_InitStruct.Pin = LED_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(LED_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : Czujnik1_Pin Czujnik2_Pin RESET_Pin */
  GPIO_InitStruct.Pin = Czujnik1_Pin|Czujnik2_Pin|RESET_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/* USER CODE BEGIN Header_StartDefaultTask */
/**
  * @brief  Function implementing the defaultTask thread.
  * @param  argument: Not used
  * @retval None
  */
/* USER CODE END Header_StartDefaultTask */
void StartDefaultTask(void const * argument)
{
  /* USER CODE BEGIN 5 */
  /* Infinite loop */
  for(;;)
  {
    osDelay(1);
  }
  /* USER CODE END 5 */
}

/* USER CODE BEGIN Header_Task1 */
/**
* @brief Function implementing the myTask1 thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_Task1 */
void Task1(void const * argument)
{
  /* USER CODE BEGIN Task1 */
  /* Infinite loop */
uint8_t tablica_cyfr[10]= {0b1000000, 0b1111001, 0b0100100, 0b0110000, 0b0011001, 0b0010010, 0b0000010, 0b1111000, 0b0000000, 0b0010000};
uint8_t Ilosc_osob=0;
uint8_t Ilosc_osob_zadana=0;

uint8_t tryb=0;
uint8_t licznik_miganie=0;

uint8_t digit1;
uint8_t digit1temp;
uint8_t digit2;
uint8_t digit2temp;

xTimerStart(Timer2Handle,0);

	HAL_GPIO_WritePin(SegA_GPIO_Port, SegA_Pin, GPIO_PIN_SET);
	HAL_GPIO_WritePin(SegB_GPIO_Port, SegB_Pin, GPIO_PIN_SET);
	HAL_GPIO_WritePin(SegC_GPIO_Port, SegC_Pin, GPIO_PIN_SET);
	HAL_GPIO_WritePin(SegD_GPIO_Port, SegD_Pin, GPIO_PIN_SET);
	HAL_GPIO_WritePin(SegE_GPIO_Port, SegE_Pin, GPIO_PIN_SET);
	HAL_GPIO_WritePin(SegF_GPIO_Port, SegF_Pin, GPIO_PIN_SET);
	HAL_GPIO_WritePin(SegG_GPIO_Port, SegG_Pin, GPIO_PIN_SET);

  for(;;)
  {
	  if (xSemaphoreTake(TrybSemaphoreHandle,2))
	  {
		  tryb++;
	  }
	  if(tryb>1)
	  {
		  tryb=0;
	  }

if (xSemaphoreTake(ResetSemaphoreHandle,2))
{
	Ilosc_osob=0;
	Ilosc_osob_zadana=0;
}
	 // xQueueReceive(modeQueueHandle,&mode, 0);
	  //obsluga wyswietlacza  tryb==0 - zliczanie osób
	  //					  tryb==1- ustawianie maksymalnej liczby osób
	 if (tryb==0)
	  	{


	  //	xQueueReceive(secQueueHandle, &sec, 0);

		 if (xQueueReceive(ilosc_osob_QueueHandle, &Ilosc_osob, 1)==pdTRUE)
		 {
	  	 digit1 = Ilosc_osob / 10;
	  	 digit1temp = tablica_cyfr[digit1];
	  	 digit2 = Ilosc_osob % 10;
	  	 digit2temp = tablica_cyfr[digit2];

	  	GPIOD->ODR = digit1temp;
	  	HAL_GPIO_WritePin(Anoda1_GPIO_Port, Anoda1_Pin, GPIO_PIN_SET);
	  	vTaskDelay(5);
	  	HAL_GPIO_WritePin(Anoda1_GPIO_Port, Anoda1_Pin, GPIO_PIN_RESET);


	  	GPIOD->ODR = digit2temp;
	  	HAL_GPIO_WritePin(Anoda2_GPIO_Port, Anoda2_Pin, GPIO_PIN_SET);
	  	vTaskDelay(5);
	  	HAL_GPIO_WritePin(Anoda2_GPIO_Port, Anoda2_Pin, GPIO_PIN_RESET);
	  	}
	  	}

	  	else if (tryb==1)
	  	{
	  		if (xSemaphoreTake(ZwiekszanieSemaphoreHandle,2))
	  		{
	  			Ilosc_osob_zadana++;
	  		}
	  		if (Ilosc_osob_zadana>99)
	  		{
	  			Ilosc_osob_zadana=0;
	  		}

	  		if(xSemaphoreTake(MiganieSemaphoreHandle, 2) == pdTRUE && licznik_miganie<50)
	  		{
	  			licznik_miganie++;
	  		}

	  		if(licznik_miganie <= 25)
	  		{
	  			HAL_GPIO_WritePin(Anoda1_GPIO_Port, Anoda1_Pin, GPIO_PIN_RESET);
	  			HAL_GPIO_WritePin(Anoda2_GPIO_Port, Anoda2_Pin, GPIO_PIN_RESET);

	  		}
	  		else if(licznik_miganie >25 && licznik_miganie < 50)
	  		{

	  		 digit1 = Ilosc_osob_zadana / 10;
	  		 digit1temp = tablica_cyfr[digit1];
	  		 digit2 = Ilosc_osob_zadana% 10;
	  		 digit2temp = tablica_cyfr[digit2];


	  		GPIOD->ODR = digit1temp;
	  		HAL_GPIO_WritePin(Anoda1_GPIO_Port, Anoda1_Pin, GPIO_PIN_SET);
	  		vTaskDelay(5);
	  		HAL_GPIO_WritePin(Anoda1_GPIO_Port, Anoda1_Pin, GPIO_PIN_RESET);


	  		GPIOD->ODR = digit2temp;
	  		HAL_GPIO_WritePin(Anoda2_GPIO_Port, Anoda2_Pin, GPIO_PIN_SET);
	  		vTaskDelay(5);
	  		HAL_GPIO_WritePin(Anoda2_GPIO_Port, Anoda2_Pin, GPIO_PIN_RESET);


	  		}
	  		else if(licznik_miganie==50)
	  		{
	  			licznik_miganie=0;
	  		}


	  	}

	 if (Ilosc_osob>=Ilosc_osob_zadana && Ilosc_osob_zadana>0)
	 {

HAL_GPIO_WritePin(LED_GPIO_Port, LED_Pin, 1);
	 }

  /* USER CODE END Task1 */
}
}

/* USER CODE BEGIN Header_Task2 */
/**
* @brief Function implementing the myTask2 thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_Task2 */
void Task2(void const * argument)
{
  /* USER CODE BEGIN Task2 */
	uint8_t time_to_press=5;

	uint8_t wcis_tryb=0;
	uint8_t wcis_reset=0;
	uint8_t wcis_zwiekszanie=0;

	uint8_t licznik_tryb=0;
	uint8_t licznik_reset=0;
	uint8_t licznik_zwiekszanie=0;
	uint8_t licznik_czujnik1=0;
	uint8_t licznik_czujnik2=0;

	uint8_t rep=0;

	xTimerChangePeriod(Timer_DEBOUNCERHandle,pdMS_TO_TICKS(10),0);
	xTimerChangePeriod(TimREPHandle,pdMS_TO_TICKS(250),0);
	xTimerStart(Timer_DEBOUNCERHandle,0);

  /* Infinite loop */
  for(;;)
  {
	  if (xSemaphoreTake(DebouncingSemaphoreHandle, portMAX_DELAY) == pdTRUE)
	  {


// OBSŁUGA PRZYCISKÓW

	  if (HAL_GPIO_ReadPin(Tryb_GPIO_Port, Tryb_Pin) == 1)
	  {
		  licznik_tryb++;
		  licznik_reset=0;
		  licznik_zwiekszanie=0;
	  }
	  else if (HAL_GPIO_ReadPin(RESET_GPIO_Port, RESET_Pin) == 1)
		  {

		  licznik_tryb=0;
		  licznik_reset++;
		  licznik_zwiekszanie=0;
	  }

	  else if (HAL_GPIO_ReadPin(Zwiekszanie_GPIO_Port, Zwiekszanie_Pin) == 1)
	 	 {

		  licznik_tryb=0;
		  licznik_reset=0;
		  licznik_zwiekszanie++;

	 	 }

	  else
	  {
		  licznik_tryb=0;
		  licznik_reset=0;
		  licznik_zwiekszanie=0;
		  wcis_tryb=0;
		  wcis_reset=0;
		  wcis_zwiekszanie=0;
		  rep=0;


	  }

	  if ( (licznik_tryb >= time_to_press) && (wcis_tryb == 0) )
	 	  {
	 		  wcis_tryb= 1;
	 		  xSemaphoreGive(TrybSemaphoreHandle);

	 	  }
	  else if ( (licznik_reset >= time_to_press) && (wcis_reset == 0) )
	  	 	  {
	  	 		  wcis_reset= 1;
	  	 		xSemaphoreGive(ResetSemaphoreHandle);
	  	 		xSemaphoreGive(Reset2SemaphoreHandle);



	  	 	  }
	  else if ( (licznik_zwiekszanie >= time_to_press) && (wcis_zwiekszanie == 0) )
	  	 	  {

	  	 		  wcis_zwiekszanie= 1;
	  	 		xSemaphoreGive(ZwiekszanieSemaphoreHandle);


	  	 	  }






// OBSŁUGA CZUJNIKÓW

	   if (HAL_GPIO_ReadPin(Czujnik1_GPIO_Port, Czujnik1_Pin) == 1)
	  	 	{

	  		  licznik_czujnik1++;

	  	    }
	   else
	   {
		   licznik_czujnik1=0;
	   }

	  	 if (HAL_GPIO_ReadPin(Czujnik2_GPIO_Port, Czujnik2_Pin) == 1)
	  	   {

	  		  licznik_czujnik2++;

	  	   }
	  	  else
	  		   {
	  			   licznik_czujnik2=0;
	  		   }

	    if ( (licznik_czujnik1 >= time_to_press))
	  	 	  {

	  	 		xSemaphoreGive(Czujnik1SemaphoreHandle);

	  	 	  }

	    if ( (licznik_czujnik2 >= time_to_press))
	  	  	  {

	  	  	 	xSemaphoreGive(Czujnik2SemaphoreHandle);

	  	  	  }

  }


	  //przytrzymanie zwiekszania

	  	  	  if ( (licznik_zwiekszanie >= 100 &&rep==0))
	   {
	  	 	  	 		xTimerStart(TimREPHandle,0);
	  	 	  	 		rep=1;


	  	  	  if (xSemaphoreTake(RepSemaphoreHandle,10)==pdTRUE && rep==1)
	  	  	  {
	  	  		xSemaphoreGive(ZwiekszanieSemaphoreHandle);
	  	  		xTimerStart(TimREPHandle,0);


	  	  	  }

	  	}
  }
}

  /* USER CODE END Task2 */


/* USER CODE BEGIN Header_Task3 */
/**
* @brief Function implementing the myTask3 thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_Task3 */
void Task3(void const * argument)
{
  /* USER CODE BEGIN Task3 */

// Zliczanie osób wychodzących i wchodzących

  /* Infinite loop */
	uint8_t stan = 1;
	uint8_t Ilosc_osob=0;
	uint8_t czujnik1 = 0;
	uint8_t czujnik2 = 0;

  for(;;)
  {
	  if (xSemaphoreTake(Czujnik1SemaphoreHandle,2))
	  {
		  czujnik1=1;
	  }
	  else
	  {
		  czujnik1=0;
	  }

	  if (xSemaphoreTake(Czujnik2SemaphoreHandle,2))
	  {
	 	  czujnik2=1;
	  }
	  else
	  {
		  czujnik2=0;
	  }
	  //******************************************************//
	  //****************OSOBY WCHODZACE**********************//
	  //******************************************************//
if((czujnik1 == 0 && czujnik2 == 0) && (stan == 1 || stan == 2 || stan == 5 || stan == 6 || stan == 9))
{
	stan = 1;
}
else if((czujnik1 == 1 && czujnik2 == 0) && (stan == 1 || stan == 2 || stan == 3))
{
	stan = 2;
}
else if((czujnik1 == 1 && czujnik2 == 1) && (stan == 2 || stan == 3 || stan == 4))
{
	stan = 3;
}
else if((czujnik1 == 0 && czujnik2 == 1) && (stan == 3 || stan == 4 || stan == 5))
{
	stan = 4;
}
else if((czujnik1 == 0 && czujnik2 == 0) && (stan == 4 || stan == 5))
{
	stan = 5;
	Ilosc_osob++;
}

//******************************************************//
//*******************OSOBY WYCHODZACE******************
//******************************************************//
else if((czujnik1 == 0 && czujnik2 == 1) && (stan == 1 || stan == 6 || stan == 7))
{
	stan = 6;
}
else if((czujnik1 == 1 && czujnik2 == 1) && (stan == 6 || stan == 7 || stan == 8))
{
	stan = 7;
}
else if((czujnik1 == 0 && czujnik2 == 1) && (stan == 7 || stan == 8 || stan == 9))
{
	stan = 8;
}
else if((czujnik1 == 0 && czujnik2 == 0) && (stan == 8 || stan == 9))
{
	stan = 9;
	Ilosc_osob--;
}

if (xSemaphoreTake(Reset2SemaphoreHandle,2))
{
	Ilosc_osob=0;
}

xQueueSend(ilosc_osob_QueueHandle,&Ilosc_osob,0);

  /* USER CODE END Task3 */
}
}

/* Callback1 function */
void Callback1(void const * argument)
{
  /* USER CODE BEGIN Callback1 */
xSemaphoreGiveFromISR(DebouncingSemaphoreHandle,0);
  /* USER CODE END Callback1 */
}

/* Callback02 function */
void Callback02(void const * argument)
{
  /* USER CODE BEGIN Callback02 */
xSemaphoreGiveFromISR(MiganieSemaphoreHandle,0);
  /* USER CODE END Callback02 */
}

/* Callback03 function */
void Callback03(void const * argument)
{
  /* USER CODE BEGIN Callback03 */
xSemaphoreGiveFromISR(RepSemaphoreHandle,0);
  /* USER CODE END Callback03 */
}

/**
  * @brief  Period elapsed callback in non blocking mode
  * @note   This function is called  when TIM1 interrupt took place, inside
  * HAL_TIM_IRQHandler(). It makes a direct call to HAL_IncTick() to increment
  * a global variable "uwTick" used as application time base.
  * @param  htim : TIM handle
  * @retval None
  */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
  /* USER CODE BEGIN Callback 0 */

  /* USER CODE END Callback 0 */
  if (htim->Instance == TIM1) {
    HAL_IncTick();
  }
  /* USER CODE BEGIN Callback 1 */


}

  /* USER CODE END Callback 1 */


/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

